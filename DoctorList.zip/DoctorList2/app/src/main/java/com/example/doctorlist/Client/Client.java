package com.example.doctorlist.Client;

import org.json.simple.JSONObject;
import org.json.simple.parser.ContainerFactory;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Client {

    public static final String services = "https://testapi.simplex48.ru/api/Web/allspec/5";


    public static void main(String[] args) {
        Client client = new Client();
        client.spinnerList();
    }

    public ArrayList spinnerList(){

        URL url = JSONUtils.createUrl(services);
        String resultJson = JSONUtils.parseUrl(url);
        ArrayList arrayList = getArrayListFromJSON(resultJson);

        for (int i = 0; i < arrayList.size();i++) {
            JSONObject obj2 = (JSONObject) arrayList.get(i);
            System.out.println(obj2.get("name"));
        }
        return arrayList;
    }


    public ArrayList getArrayListFromJSON(String json){
        ContainerFactory containerFactory = new ContainerFactory() {
            @Override
            public Map createObjectContainer() {
                return null;
            }
            @Override
            public List creatArrayContainer() {
                return new ArrayList<>();
            }
        };
        JSONParser parser = new JSONParser();

        try {
            ArrayList parse = (ArrayList) parser.parse(json, containerFactory);
            return parse;
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return null;
    }
}
