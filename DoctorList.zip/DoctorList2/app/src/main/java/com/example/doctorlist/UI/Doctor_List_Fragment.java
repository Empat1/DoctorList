package com.example.doctorlist.UI;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.doctorlist.Client.Client;
import com.example.doctorlist.Client.JSONUtils;
import com.example.doctorlist.R;

import java.util.ArrayList;
import java.util.List;

public class Doctor_List_Fragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_doctor__list_, container, false);

        Spinner spinner = root.findViewById(R.id.spinner);

        List<String> list =new ArrayList<>();
        list.add("1");
        list.add("2");

        //Client client = new Client();
        //ArrayList arrayList = client.getArrayListFromJSON(Client.services);

        ArrayAdapter<String> adapter  =  new  ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_item,list);
        spinner.setAdapter(adapter);



        return root;
    }
}